package GUI;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

public class Node1  {
	    private Map<Node1, Double> distances = new HashMap<Node1, Double>();

	    public final String name;

	    public Node1(String name) {
	        this.name = name;
	    }

	    public Set<Node1> getAdjacentNodes() {
	        return Collections.unmodifiableSet(distances.keySet());
	    }

	    public double getDistance(Node1 node) {
	        return distances.get(node);
	    }

	    public void setDistance(Node1 node, double distance) {
	        distances.put(node, distance);
	    }

	    @Override
	    public String toString() {
	        return (name == null ? "Node@" + Integer.toHexString(hashCode()) : name);
	    }
	}

