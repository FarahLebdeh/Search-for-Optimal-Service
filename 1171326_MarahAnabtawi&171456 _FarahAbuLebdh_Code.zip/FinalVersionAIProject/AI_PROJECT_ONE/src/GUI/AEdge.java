package GUI;

public class AEdge {
	 public final double cost;
     public final ANode target;

     public AEdge(ANode targetNode, double costVal){
             target = targetNode;
             cost = costVal;
     }

}
