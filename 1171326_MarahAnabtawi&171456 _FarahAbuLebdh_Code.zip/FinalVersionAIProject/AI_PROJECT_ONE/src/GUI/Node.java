package GUI;

public class Node {
	Vertices element;
	Node left,right;
	public Node(Vertices element) {
		super();
		this.element = element;
		left = null;
		right = null;
	}
}
