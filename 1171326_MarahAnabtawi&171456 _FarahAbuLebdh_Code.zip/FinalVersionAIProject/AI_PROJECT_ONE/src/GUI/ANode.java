package GUI;

public class ANode {
	
	  public final String value;
      public double g_scores;
      public final double h_scores;
      public double f_scores = 0;
      public AEdge[] adjacencies;
      public ANode parent;

      public ANode(String val, double hVal){
              value = val;
              h_scores = hVal;
      }

      public String toString(){
              return value;
      }


}
