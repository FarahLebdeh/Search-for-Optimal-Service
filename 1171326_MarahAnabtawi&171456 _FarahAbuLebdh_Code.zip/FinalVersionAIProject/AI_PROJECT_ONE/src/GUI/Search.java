package GUI;

public abstract class Search {
	Vertices startGoal;
	Vertices endGoal;
	
	public Search(Vertices start, Vertices end) {
		this.startGoal=start;
		this.endGoal=end;
		
	}
	public abstract boolean excute();

}