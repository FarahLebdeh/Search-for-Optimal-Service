package GUI;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Optional;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.Stack;

import javax.swing.JOptionPane;

//import GUI.AI_Contruler.AStarThing;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class AI_Contruler implements Initializable{
    @FXML
    Pane root = new Pane();
    @FXML
    private BorderPane border;
    @FXML
    Button clear = new Button();
    @FXML
    private ImageView image;
    @FXML
    private Button clearao;
    @FXML
    boolean verF = false;
    @FXML
    boolean edgeF = false;
    @FXML
    boolean clearF = false;
    @FXML
    private Label pathText;
    @FXML
    public static Vertices data[] = new Vertices[200];
    private PrintWriter savetxt;
    private Scanner scan;
    @FXML
    Labeled startVertex;
    private boolean Vstart = false;
    private Vertices Vbegin;
    private boolean BFSboolean;
    private boolean UCSboolean;
    private boolean DFSboolean;
    private boolean OBTboolean;
    private boolean Astarboolean;
    LinkedList<Vertices> visited = new LinkedList<>();
    LinkedList<Vertices> stack = new LinkedList<>();
    public static ArrayList<Vertices> vert_DEPTHFirst = new ArrayList<>();



    public void BFS()
    {
        System.out.println("BFS");
        BFSboolean = true;
        Vstart = true;
        startVertex.setText("Please select start vertex:");
        startVertex.setVisible(true);
    }

    public void UCS()
    {
        System.out.println("UCS");
        UCSboolean = true;
        Vstart = true;
        startVertex.setText("Please select start vertex:");
        startVertex.setVisible(true);
    }

    @FXML
    public void Astar()
    {

        System.out.println("A*");
        Astarboolean = true;
        Vstart = true;
        startVertex.setText("Please select start vertex:");
        startVertex.setVisible(true);

    }

    @FXML
    public void DFS()
    {
        System.out.println("DFS");
        DFSboolean = true;
        Vstart = true;
        startVertex.setText("Please select start vertex:");
        startVertex.setVisible(true);

    }

    @FXML
    public void OPT()
    {
        System.out.println("OPTIMAL");
        OBTboolean = true;
        Vstart = true;
        startVertex.setText("Please select start vertex:");
        startVertex.setVisible(true);

    }

    @FXML
    void clearAO(ActionEvent event) throws IOException {
    /*	 pathText.setText("");
         startVertex.setText("Please select start vertex:");
         startVertex.setVisible(false);
    	 root.getChildren().remove(image);
         root.getChildren().remove(startVertex);
       //  root.getChildren().clear();
         root.getChildren().add(image);
         root.getChildren().add(startVertex);
         System.out.println("clear");
        // root.getChildren().addAll();
       //  readFile();*/
    }

    @FXML
    public void ClearMap() throws FileNotFoundException
    {
        BFSboolean = false;
        Vstart = false;
        UCSboolean = false;
        DFSboolean = false;
        OBTboolean = false;
        Astarboolean = false;
        pathText.setText("");
        startVertex.setText("Please select start vertex:");
        startVertex.setVisible(false);
        lNode n = alledgeDrow.getFirstNode();
        for (int i = 0; i < alledgeDrow.getlength(); i++)
        {
            ((edge) n.element).line.setStroke(Color.DIMGRAY);

            n = n.Next;
        }
        alledgeDrow = new List();
        for (int i = 0; i < data.length; i++)
        {
            if (data[i] != null)
            {

                data[i].isUsed = false;
                data[i].parent = null;
                data[i].costEdge = 0;
            }
        }
     //   root.getChildren().remove(image);
      //  root.getChildren().remove(startVertex);
          root.getChildren().clear();
          root.getChildren().add(image);
          root.getChildren().add(startVertex);
          int max = 0;
          File info = new File("files/data.txt");
          scan = new Scanner(info);
          while (scan.hasNextLine())
          {
              String line = scan.nextLine();
              String sp[] = line.split("#");
              String sp2[] = sp[0].split(",");
              int i = Integer.parseInt(sp2[0]);

              if (i > max)
                  max = i;

              if (sp.length > 1)
              {

                  String sp3[] = sp[1].split(",");

                  for (int j = 0; j < sp3.length; j++)
                  {
                      String sp4[] = sp3[j].split(":");

                      double startX = data[i].getCenterX();
                      double startY = data[i].getCenterY();
                      double endX;
                      double endY;
                      double m = (data[Integer.parseInt(sp4[0])].getCenterY() - startY)
                                 / (data[Integer.parseInt(sp4[0])].getCenterX() - startX);
                      double angle = Math.atan(m);
                      if (startX <= data[Integer.parseInt(sp4[0])].getCenterX())
                      {
                          endX = data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle + Math.PI)
                                 + data[Integer.parseInt(sp4[0])].getCenterX();
                          startX += data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle);
                          endY = data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle + Math.PI)
                                 + data[Integer.parseInt(sp4[0])].getCenterY();
                          startY += data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle);
                      }
                      else
                      {
                          endX = data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle)
                                 + data[Integer.parseInt(sp4[0])].getCenterX();
                          startX += data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle + Math.PI);
                          startY += data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle + Math.PI);
                          endY = data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle)
                                 + data[Integer.parseInt(sp4[0])].getCenterY();
                      }

                      //edge c = new edge(i, Integer.parseInt(sp4[0]), Double.parseDouble(sp4[1]), startX, startY, endX,endY, get);

                      edge c = new edge(i, Integer.parseInt(sp4[0]), Double.parseDouble(sp4[1]), startX, startY, endX,
                                        endY);

                      c.setOnMouseMoved(e ->
                      {
                          ((edge) e.getSource()).l.setLayoutX(e.getX() - 26);
                          ((edge) e.getSource()).l.setLayoutY(e.getY() - 10);

                          ((edge) e.getSource()).l.setVisible(true);
                      });
                      c.setOnMouseExited(e ->
                      {
                          ((edge) e.getSource()).l.setVisible(false);
                      });
                      data[i].getCost().add(c);
                      data[Integer.parseInt(sp4[0])].getCost().add(c);
                      root.getChildren().add(c);
//						data[i].getH().add(c);
//						data[Integer.parseInt(sp4[0])].getH().add(c);
//						root.getChildren().add(c);
                  }
              }
          }
          Vertices.vNum = max + 1;

          for (int i = 1; i < data.length; i++)
          {
              if (data[i] != null)
              {
                  root.getChildren().add(data[i]);
              }
              else
                  break;
          }

        System.out.println("clear");


    }


    @FXML
    private void save() throws FileNotFoundException
    {
        File savedata = new File("files/data - Copy.txt");
        savetxt = new PrintWriter(savedata);
        for (int i = 1; i < data.length; i++)
        {
            if (data[i] != null)
            {
                String data1 = data[i].getVid() + "," + data[i].getName() + "," + data[i].getCenterX() + ","
                + data[i].getCenterY();
                String data2 = new String();
                String tmp = new String();
                for (int j = 0; j < data[i].getCost().size(); j++)
                {
                    edge tmpCost = data[i].getCost().get(j);
                    tmp = tmpCost.getVid2() + ":" + tmpCost.getCost() + ",";
                    data2 += tmp;
                }
                savetxt.println(data1 + "#" + data2);
            }

        }
        savetxt.close();

    }


    @Override
    public void initialize(URL location, ResourceBundle resources)
    {

        // TODO Auto-generated method stub
        root.setOnMousePressed(e ->
        {
            if (verF)
            {
                TextInputDialog dialog = new TextInputDialog("Name Of city ");
                dialog.setTitle("Name Of city");
                dialog.setHeaderText("");
                dialog.setContentText("Please enter the name of City ");
                Optional<String> result = dialog.showAndWait();
                try
                {
                    String name = result.get();
                    int i = Vertices.vNum;
                    data[i] = new Vertices(e.getX(), e.getY(), 5);
                    data[i].setName(name);
                    root.getChildren().add(data[i]);
                }
                catch (Exception ew)
                {
                    // TODO: handle exception
                }
            }
        });

        clear.setOnAction(e ->
        {
            verF = false;
            edgeF = false;
            clearF = true;
        });

    }

    @FXML
    public void readFile()
    {
        File info = new File("files/data.txt");
        try
        {
            int max = 0;
            scan = new Scanner(info);
            while (scan.hasNextLine())
            {
                String line = scan.nextLine();
                String sp[] = line.split("#");
                String sp2[] = sp[0].split(",");
                int i = Integer.parseInt(sp2[0]);
                data[i] = new Vertices(Double.parseDouble(sp2[2]), Double.parseDouble(sp2[3]) + 15, 5, i, sp2[1]);
                data[i].setOnMouseMoved(e ->
                {
                    data[i].setFill(Color.BLACK);
                });
                data[i].setOnMouseExited(e ->
                {
                    data[i].setFill(Color.HOTPINK);
                });
                data[i].setOnMouseClicked(e ->
                {

                    if (BFSboolean)
                    {
                        startVertex.setText("Please select end vertex:");
                        if (Vstart)
                        {
                            Vbegin = (Vertices) e.getSource();
                            Vstart = false;
                        }
                        else
                        {
                           // ClearMap();
                            BFSAlgorethim(Vbegin, (Vertices) e.getSource());
                            BFSDrowingPath((Vertices) e.getSource());
                            startVertex.setText("Please select start verte:");
                            startVertex.setVisible(false);
                        }
                    }
                    if (UCSboolean)
                    {
                        startVertex.setText("Please select end vertex:");
                        if (Vstart)
                        {
                            Vbegin = (Vertices) e.getSource();
                            Vstart = false;
                        }
                        else
                        {
                           // ClearMap();
                            USAlgorethim(Vbegin, (Vertices) e.getSource());
                            UCSDrowingPath((Vertices) e.getSource());
                            startVertex.setText("Please select start vertex:");
                            startVertex.setVisible(false);
                        }
                    }
                    if (DFSboolean)
                    {
                        startVertex.setText("Please select end vertex:");
                        if (Vstart)
                        {
                            Vbegin = (Vertices) e.getSource();
                            Vstart = false;
                        }
                        else
                        {
                           // ClearMap();
                            DFSAlgorethim(Vbegin, (Vertices) e.getSource());
                            DFSDrowingPath((Vertices) e.getSource());

                            startVertex.setText("Please select start vertex:");
                            startVertex.setVisible(false);
                        }
                    }
                    if (OBTboolean)
                    {
                        startVertex.setText("Please select end vertex:");
                        if (Vstart)
                        {
                            Vbegin = (Vertices) e.getSource();
                            Vstart = false;
                        }
                        else
                        {
                          //  ClearMap();
                            OPTAlgorethim(Vbegin, (Vertices) e.getSource());
                          //  OPTDrowingPath((Vertices) e.getSource());

                            startVertex.setText("Please select start vertex:");
                            startVertex.setVisible(false);
                        }
                    }
                    if (Astarboolean)
                    {
                        startVertex.setText("Please select end vertex:");
                        if (Vstart)
                        {
                            Vbegin = (Vertices) e.getSource();
                            Vstart = false;
                        }
                        else
                        {
                            //ClearMap();
                            AstarAlgorethim(Vbegin, (Vertices) e.getSource());


                            //AstarDrowingPath((Vertices) e.getSource());
                            startVertex.setText("Please select start vertex:");
                            startVertex.setVisible(false);
                        }
                    }

                });

            }
            scan = new Scanner(info);
            while (scan.hasNextLine())
            {
                String line = scan.nextLine();
                String sp[] = line.split("#");
                String sp2[] = sp[0].split(",");
                int i = Integer.parseInt(sp2[0]);

                if (i > max)
                    max = i;

                if (sp.length > 1)
                {

                    String sp3[] = sp[1].split(",");

                    for (int j = 0; j < sp3.length; j++)
                    {
                        String sp4[] = sp3[j].split(":");

                        double startX = data[i].getCenterX();
                        double startY = data[i].getCenterY();
                        double endX;
                        double endY;
                        double m = (data[Integer.parseInt(sp4[0])].getCenterY() - startY)
                                   / (data[Integer.parseInt(sp4[0])].getCenterX() - startX);
                        double angle = Math.atan(m);
                        if (startX <= data[Integer.parseInt(sp4[0])].getCenterX())
                        {
                            endX = data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle + Math.PI)
                                   + data[Integer.parseInt(sp4[0])].getCenterX();
                            startX += data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle);
                            endY = data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle + Math.PI)
                                   + data[Integer.parseInt(sp4[0])].getCenterY();
                            startY += data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle);
                        }
                        else
                        {
                            endX = data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle)
                                   + data[Integer.parseInt(sp4[0])].getCenterX();
                            startX += data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle + Math.PI);
                            startY += data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle + Math.PI);
                            endY = data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle)
                                   + data[Integer.parseInt(sp4[0])].getCenterY();
                        }

                        //edge c = new edge(i, Integer.parseInt(sp4[0]), Double.parseDouble(sp4[1]), startX, startY, endX,endY, get);

                        edge c = new edge(i, Integer.parseInt(sp4[0]), Double.parseDouble(sp4[1]), startX, startY, endX,
                                          endY);

                        c.setOnMouseMoved(e ->
                        {
                            ((edge) e.getSource()).l.setLayoutX(e.getX() - 26);
                            ((edge) e.getSource()).l.setLayoutY(e.getY() - 10);

                            ((edge) e.getSource()).l.setVisible(true);
                        });
                        c.setOnMouseExited(e ->
                        {
                            ((edge) e.getSource()).l.setVisible(false);
                        });
                        data[i].getCost().add(c);
                        data[Integer.parseInt(sp4[0])].getCost().add(c);
                        root.getChildren().add(c);
//						data[i].getH().add(c);
//						data[Integer.parseInt(sp4[0])].getH().add(c);
//						root.getChildren().add(c);
                    }
                }
            }
            Vertices.vNum = max + 1;

            for (int i = 1; i < data.length; i++)
            {
                if (data[i] != null)
                {
                    root.getChildren().add(data[i]);
                }
                else
                    break;
            }

        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    List alledgeDrow = new List();


    //************************************************** Breadth First Algorithm *********************************************************

    private void BFSDrowingPath(Vertices source)
    {
        if (source.parent != null)
        {
            for (int i = 0; i < source.getCost().size(); i++)
            {
                edge e = source.getCost().get(i);
                if (e.getVid1() == source.parent.getVid())
                {
                    e.line.setStroke(Color.RED );
                    alledgeDrow.addLast(e);
                }
                else if (e.getVid2() == source.parent.getVid())
                {
                    e.line.setStroke(Color.RED );
                    alledgeDrow.addLast(e);
                }
            }
            //pathGoal.setVisible(true);
            //pathGoal.setText( source.getName()+"\n");
            System.out.println(source.getName());
            BFSDrowingPath(source.parent);

        }
       // pathGoal.setVisible(true);
       // pathGoal.setText( source.getName()+"\n");
    }

    public void BFSAlgorethim(Vertices begin, Vertices end)
    {
    	System.out.println("Start :" + begin);
    	System.out.println("Goal :" + end);

        quewe q = new quewe();
        q.inq(begin);
        pathText.setVisible(true);
        pathText.setText(" Start :" + begin + "\n" + " Goal :" + end +"\n");
        System.out.println("Path from goal to start :");
    	System.out.println(begin);

        while (!q.empty())
        {
            Vertices v = (Vertices) q.deq();
            //System.out.println("hiiiiiiiii " +v);

            v.isUsed = true;

            for (int i = 0; i < v.getCost().size(); i++)
            {
                Vertices d = data[v.getCost().get(i).getVid1()];
                if (d.getVid() != v.getVid())
                {
                    if (d == end)
                    {
                        d.parent = v;
//                        System.out.println("Path from goal to start : ");
                        return;
                    }
                    else
                    {
                        if (!d.isUsed)
                        {
                            q.inq(d);
                            if (d.parent == null)
                                d.parent = v;
                        }
                    }
                }
                else
                {
                    d = data[v.getCost().get(i).getVid2()];
                    if (d == end)
                    {
                        d.parent = v;
//                        System.out.println("Path from goal to start :");
                        return;
                    }
                    else
                    {
                        if (!d.isUsed)
                        {
                            q.inq(d);
                            if (d.parent == null)
                                d.parent = v;
                        }
                    }
                }
            }
        }

    }
//************************************************** Depth First Algorithm *********************************************************

    private void DFSDrowingPath(Vertices source)
    {
        if (source.parent != null)
        {
            for (int i = 0; i < source.getCost().size(); i++)
            {
                edge e = source.getCost().get(i);
                if (e.getVid1() == source.parent.getVid())
                {
                    e.line.setStroke(Color.RED);
                    alledgeDrow.addLast(e);
                }
                else if (e.getVid2() == source.parent.getVid())
                {
                    e.line.setStroke(Color.RED);
                    alledgeDrow.addLast(e);
                }
            }
            System.out.println(source.getName());
            BFSDrowingPath(source.parent);
        }
    }

    public void DFSAlgorethim(Vertices start, Vertices end)
    {
    	System.out.println("Start :" + start);
    	System.out.println("Goal :" + end);
    	pathText.setVisible(true);
        pathText.setText(" Start :" + start + "\n" + " Goal :" + end +"\n");

        stack.push(start);
        while (!stack.isEmpty())
        {
            Vertices v = stack.pop();
            if (v.isUsed)
                continue;
            v.isUsed = true;
            //
            for (int i = 0; i < v.getCost().size(); i++)
            {
                Vertices d = data[v.getCost().get(i).getVid2()];
                if (!d.isUsed)
                {
                    stack.push(d);
                 //   System.out.println(d.getName() + " is Found");
                }
                if (d.getVid() != v.getVid())
                {
                    if (d == end)
                    {
                        d.parent = v;
                        //System.out.println("find");
                        return;
                    }
                    else
                    {
                        if (!d.isUsed)
                        {
                            stack.push(d);
                            if (d.parent == null)
                                d.parent = v;
                        }
                    }
                }

            }
        }
    }

//***************************************************** Uniform ***********************************************************************************

    private void UCSDrowingPath(Vertices source)
    {
        if (source.parent != null)
        {
            for (int i = 0; i < source.getCost().size(); i++)
            {
                edge e = source.getCost().get(i);
                if (e.getVid1() == source.parent.getVid())
                {
                    e.line.setStroke(Color.RED);
                    alledgeDrow.addLast(e);
                }
                else if (e.getVid2() == source.parent.getVid())
                {
                    e.line.setStroke(Color.RED);
                    alledgeDrow.addLast(e);
                }
            }
            System.out.println(source.getName());
            BFSDrowingPath(source.parent);
        }

    }
    private void USAlgorethim(Vertices vbegin2, Vertices end)
    {
    	System.out.println("Start :" + vbegin2);
    	System.out.println("Goal :" + end);
    	pathText.setVisible(true);
        pathText.setText(" Start :" + vbegin2 + "\n" + " Goal :" + end +"\n");
        int count1 = 0;
        int count2 = 0;
        // int count3 = 0;
        minHeap heap = new minHeap(200);
        vbegin2.costEdge = 0;
        Vertices temp = vbegin2; // source vertix
        temp.isUsed = true; // This mean that ive visited this city
        while (true)
        {
            if (temp.getVid() == end.getVid())
            {
                count1++;
                System.out.println("done");
                break;
            }
            else
            {
                for (int i = 0; i < temp.getCost().size(); i++)
                {
                    edge c = temp.getCost().get(i);
                    Vertices v = data[c.getVid1()]; // Destination Vertices

                    if (temp.getVid() != v.getVid())
                    {
                        count2++;
                        if (!v.isUsed)
                        {
                            if (v.parent == null)
                            {
                                v.parent = temp;
                                v.edgeparent = c;
                                v.costEdge = c.cost + v.parent.costEdge;
                            }
                            else
                            {
                                double a, b;
                                a = c.cost + v.parent.costEdge;
                                b = v.edgeparent.cost + v.parent.costEdge;
                                if (b > a)
                                    v.parent = temp;
                                v.costEdge = c.cost + v.parent.costEdge;
                            }

                            heap.insert(new Node(v));
                            System.out.print(v.getName() + "--" + v.costEdge + " %% ");
                        }
                    }
                    else
                    {
                        v = data[c.getVid2()];
                        if (!v.isUsed)
                        {
                            if (v.parent == null)
                            {
                                v.parent = temp;
                                v.edgeparent = c;
                                v.costEdge = c.cost + v.parent.costEdge;
                            }
                            else
                            {
                                double a, b;
                                a = c.cost + v.parent.costEdge;
                                b = v.edgeparent.cost + v.parent.costEdge;
                                if (b > a)
                                    v.parent = temp;
                                v.costEdge = c.cost + v.parent.costEdge;
                            }

                            heap.insert(new Node(v));
                            System.out.print(v.getName() + "--" + v.costEdge + " %% ");
                        }
                    }
                }
                if (heap.size == 0)

                    break;
                System.out.println();

                temp = heap.deleteMin().element;
                temp.isUsed = true;
                System.out.println("temp = " + temp.getName());
            }

        }
        System.out.println(count1);
        System.out.println(count2);
    }
    //*********************************************************************************************************************************//
    public double heuristic (Vertices vbegin2, Vertices end)
    {
        return Math.abs((end.getCenterX() - vbegin2.getCenterX()) + (end.getCenterY() - vbegin2.getCenterY()));
    }
    //**************************************************** About  **********************************************************************//

    public void about()
    {
        Alert infoMsg = new Alert(AlertType.INFORMATION);
        infoMsg.setContentText(
            "This Is The Artificial intelligence  project \n Done by Marah Anabtawai and Farah Abu Lebdeh\nCourse Instructor Dr. Adnan Yahya");
        infoMsg.show();
    }
    //****************************************************   A start  *******************************************************************

    public double displacement(int v1, int v2)
    {
        return (Math.sqrt(Math.pow((data[v1].getCenterX() - data[v2].getCenterX()), 2)
                          + Math.pow((data[v1].getCenterY() - data[v2].getCenterY()), 2))) * 0.3;
    }
    public static double geth(double cx, double cy, double ex, double ey)
    {

    	double c = 1;
    	double d_min = Math.min(cx - ex, cy - ey);
    	double d_max = Math.max(cx - ex, cy - ey);
    	double h = c * d_min + (d_max - d_min);
        if (h < 0) //make h positive in case it's negative
        {
            h = h * -1;
        }

        return h;
    }
    @FXML
    void clearA(ActionEvent event) {
    	root.getChildren().remove(event);
    	System.out.println("doneeeeee");
    	}

    @SuppressWarnings("unchecked")
	public void AstarAlgorethim(Vertices start, Vertices end)   // A Star Search Algorithm
    {


    	double cx=start.getCenterX();
    	double cy=start.getCenterY();
    	double ex=end.getCenterX();
    	double ey=end.getCenterY();
        String a =start.getName();
        String b =end.getName();
        boolean found = false;
        int v1 = start.getVid();
        int v2 = end.getVid();
        HashSet<Integer> visited = new HashSet<>();
        PriorityQueue<AStarThing> heap = new PriorityQueue<>();
        heap.add(new AStarThing(v1, displacement(v1, v2)));
        pathText.setVisible(true);
        pathText.setText(" ID start :  " + start.getVid() + " , Start Name is: " + start.getName() + " , Heuristic : " + geth( cx,  cy,  ex,  ey)+ "\n" + " ID end:  "    + end.getVid() + "   , End Name is: " + end.getName()     + " , Heuristic :  " + geth( cx,  cy,  cx,  cy));
        System.out.println("ID start :  " + start.getVid() + " , Start Name is: " + start.getName() + " , Heuristic : " + geth( cx,  cy,  ex,  ey));
        System.out.println("ID end:  "    + end.getVid() + "   , End Name is: " + end.getName()     + " , Heuristic :  " + geth( cx,  cy,  cx,  cy));
        System.out.println("Path from goal to start city: = " );
        System.out.println("ID :  "    + end.getVid() + ", Name is: " + end.getName()  + " , Heuristic :  " + geth( cx,  cy,  cx,  cy));
        while (!heap.isEmpty() && !found)
        {
            AStarThing temper = heap.remove();
            if (v2 == temper.vertId)
            {
                found = true;
            }
            visited.add(temper.vertId);
            for (int i = 0; i < data[temper.vertId].getCost().size(); i++)
            {
                int child = data[temper.vertId].getCost().get(i).getVid2();
                if (!visited.contains(child))
                {
                    heap.add(new AStarThing(child, temper.cost + data[temper.vertId].getCost().get(i).getCost()
                                            + geth(cx,  cy,  ex,  ey)));
                    data[child].setParentID(temper.vertId);
                    visited.add(child);
                }
            }


            if (found)
            {  //clearAstar(end,true);

            	int Goal = end.getVid();
                while (data[Goal].getParentID() != 0)
                {
                    Line lineTmp = new Line(data[Goal].getCenterX(), data[Goal].getCenterY(),
                                            data[data[Goal].getParentID()].getCenterX(),
                                            data[data[Goal].getParentID()].getCenterY());

                    lineTmp.setStroke(Color.RED);
                    lineTmp.setStrokeWidth(3);
                    root.getChildren().add(lineTmp);
                    Goal = data[Goal].getParentID();
                    String Goal2 = data[Goal].getName();
                    try {
                    	  //  Block of code to try
                        System.out.println("ID :  " + Goal+ " , Name is:  " + Goal2 + " , Heuristic " + geth(data[Goal].getCenterX(),data[Goal].getCenterY() , data[data[Goal].getParentID()].getCenterX(),
                        		data[data[Goal].getParentID()].getCenterY()));

                    	}
                    	catch(Exception e) {
                    	  //  Block of code to handle errors
                    	}



                }
                return ;


           }

        }
    }

  /*  public void clearAstar( Vertices end,boolean t) {

    	if(t) {


    	int Goal = end.getVid();
        while (data[Goal].getParentID() != 0)
        {
            Line lineTmp = new Line(data[Goal].getCenterX(), data[Goal].getCenterY(),
                                    data[data[Goal].getParentID()].getCenterX(),
                                    data[data[Goal].getParentID()].getCenterY());

            lineTmp.setStroke(Color.RED);
            lineTmp.setStrokeWidth(3);
            root.getChildren().add(lineTmp);

            Goal = data[Goal].getParentID();
            String Goal2 = data[Goal].getName();
            System.out.println("ID :  " + Goal+ " , Name is:  " + Goal2 + " , Heuristic " + geth(data[Goal].getCenterX(),data[Goal].getCenterY() , data[data[Goal].getParentID()].getCenterX(),
            		data[data[Goal].getParentID()].getCenterY()));


        }
        return ;

    	}

    }*/



    class AStarThing implements Comparable<AStarThing>   // A Star Search Class
    {
        int vertId;
        double cost;

        public AStarThing(int v, double c)
        {
            vertId = v;
            cost = c;
        }

        @Override
        public int compareTo(AStarThing other)
        {
            return (int) (this.cost - other.cost);
        }
    }




//


  //******************************************************** Optimal 2  *************************************************************//
    public void OPTAlgorethim(Vertices start, Vertices end)
    {
        String a =start.getName();
        String b =end.getName();
        boolean found = false;
        int v1 = start.getVid();
        int v2 = end.getVid();
        double cx=start.getCenterX();
    	double cy=start.getCenterY();
    	double ex=end.getCenterX();
    	double ey=end.getCenterY();
    	double factor = getRandomNumberUsingNextDou(0.0,2.0);
    	//Speed = Distance / Time
        HashSet<Integer> visited = new HashSet<>();
        PriorityQueue<AStarThing> heap = new PriorityQueue<>();
        heap.add(new AStarThing(v1, geth( cx,  cy,  ex,  ey)));//      System.out.println("Factor :  " + factor);
       // System.out.println("Heuristic :  " + displacement(v1, v2));
//        System.out.println("ID start :  " + start.getVid() + " , Start Name is: " + start.getName());
//        System.out.println("ID end:  " + end.getVid() + "                , End Name is: " + end.getName()+"Heuristic :  " + displacement(v1, v2));
//        System.out.println("Path from goal to start city: = " );
//        System.out.println("ID :  "    + end.getVid() + ", Name is: " + end.getName() );
        System.out.println("ID start :  " + start.getVid() + " , Start Name is: " + start.getName() + ",  Heuristic : " + geth( cx,  cy,  ex,  ey));
        System.out.println("ID end:  "    + end.getVid() + "   , End Name is: " + end.getName()     + " , Heuristic :  " + geth( cx,  cy,  cx,  cy));
        System.out.println("Path from goal to start city: = " );
        System.out.println("ID :  "    + end.getVid() + ", Name is: " + end.getName()  + " , Heuristic :  " + geth( cx,  cy,  cx,  cy));
        pathText.setVisible(true);
        pathText.setText(" ID start :  " + start.getVid() + " , Start Name is: " + start.getName() + " , Heuristic : " + geth( cx,  cy,  ex,  ey)+" , Factor :  " + getRandomNumberUsingNextDou(0.0,2.0) + "\n" + " ID end:  "    + end.getVid() + "   , End Name is: " + end.getName()     + " , Heuristic :  " + geth( cx,  cy,  cx,  cy)+ " ,Factor :  " + getRandomNumberUsingNextDou(0.0,2.0) + "\n");

        while (!heap.isEmpty() && !found)
        {
            AStarThing temper = heap.remove();
            if (v2 == temper.vertId)
            {
                found = true;
            }
            visited.add(temper.vertId);
            for (int i = 0; i < data[temper.vertId].getCost().size(); i++)
            {
//               	System.out.println("*************************************************");
//            	System.out.println(data[temper.vertId].getCost().size());
//            	System.out.println("//////////////////////////////////////////////");
                String nameNode = data[temper.vertId].getName();

                int v_start= data[temper.vertId].getCost().get(i).getVid1();
                int v_end = data[temper.vertId].getCost().get(i).getVid2();
                double dis =geth(cx,  cy,  ex,  ey);
            	double speed = dis / factor;
            	if( factor >1){
                    System.out.println("Factor :  " + factor);
            		System.out.println("Speed :  "+ speed + " ,Name Node:   " + nameNode);
            		System.out.println("congestion factor , long time");
            	}
            		else{
            	        System.out.println("Factor :  " + factor);
                		System.out.println("Speed :  "+ speed + " ,Name Node:   " + nameNode);
                		System.out.println("No congestion factor, less time");
            	}
                int child = data[temper.vertId].getCost().get(i).getVid2();
                if (!visited.contains(child))
                {
                    heap.add(new AStarThing(child, temper.cost + data[temper.vertId].getCost().get(i).getCost()
                                            + (geth(cx,  cy,  ex,  ey)*factor)));
                    data[child].setParentID(temper.vertId);
                    visited.add(child);
                }
            }

            if (found)
            {
                int Goal = v2;
                while (data[Goal].getParentID() != 0)
                {
                    Line lineTmp = new Line(data[Goal].getCenterX(), data[Goal].getCenterY(),
                                            data[data[Goal].getParentID()].getCenterX(),
                                            data[data[Goal].getParentID()].getCenterY());
                    lineTmp.setStroke(Color.RED);
                    lineTmp.setStrokeWidth(3);
                    root.getChildren().add(lineTmp);
                    Goal = data[Goal].getParentID();
                    String Goal2 = data[Goal].getName();
                   // System.out.println("ID :  " + Goal+ " , Name is: " + Goal2 );
                    //System.out.println("ID :  " + end.getVid() + " ,Name is: " + end.getName());
                  //  System.out.println("ID :  " + temper+ " , Name is: " + Goal2 );
                    // System.out.println("ID :  " + Goal+ " , Name is: " + Goal2 );
                	try {
                		  System.out.println("ID :  " + Goal+ " , Name is:  " + Goal2 + " , Heuristic " + geth(data[Goal].getCenterX(),
                          		data[Goal].getCenterY() , data[data[Goal].getParentID()].getCenterX(),
                          		data[data[Goal].getParentID()].getCenterY()) );              		}
              		catch(Exception e) {
              		  //  Block of code to handle errors
              		}



                }
                return ;
            }
        }
    }

    public double getRandomNumberUsingNextDou(double min, double max) {
        Random random = new Random();
        return ((max - min) + min)*random.nextDouble();
    }

    //********************************************************************************************************************************//


}