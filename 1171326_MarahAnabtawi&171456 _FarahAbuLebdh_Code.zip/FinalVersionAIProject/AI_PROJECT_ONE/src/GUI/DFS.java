package GUI;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

public class DFS extends Search {
	Vertices startNode;
	Vertices goalNode;

	// private Stack<Integer> stack;

	public DFS(Vertices src, Vertices dest) {
		super(src, dest);
		this.startNode = src;
		this.goalNode = dest;

	}

	@Override
	public boolean excute() {
		if (this.startNode.equals(goalNode)) {
			System.out.println("Goal Node Found at 0 depth");
			System.out.println(startNode);
		}
		Stack<Vertices> nodeStack = new Stack<>();
		ArrayList<Vertices> visitedNodes = new ArrayList<>();

		nodeStack.add(startNode);

		while (!nodeStack.isEmpty()) {
			Vertices current = nodeStack.pop();
			if (current.equals(goalNode)) {
				System.out.print(visitedNodes.toString().toString());
				System.out.println("Goal node found");
				return true;
			} else {
				visitedNodes.add(current);
				nodeStack.add(current);
			}
		}
		return false;
	}
}