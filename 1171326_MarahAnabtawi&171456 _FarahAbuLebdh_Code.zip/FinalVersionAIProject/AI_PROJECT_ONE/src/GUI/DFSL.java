package GUI;

import java.util.ArrayList;
import java.util.Stack;

public class DFSL extends Search {

	Vertices startNode;
	Vertices goalNode;
	int depth = 0;

	public DFSL(Vertices start, Vertices goalNode) {
		super(start, goalNode);
		this.startNode = start;
		this.goalNode = goalNode;
	}

	@Override
	public boolean excute() {
		int limit = 4;

		Stack<Vertices> nodeStack = new Stack<>();
		ArrayList<Vertices> visitedNodes = new ArrayList<>();
		nodeStack.add(startNode);

		depth = 0;

		while (!nodeStack.isEmpty()) {
			if (depth <= limit) {
				Vertices current = nodeStack.pop();
				if (current.equals(goalNode)) {
					System.out.print(visitedNodes);
					System.out.println("Goal node found");
					return true;
				} else {
					visitedNodes.add(current);
					nodeStack.add(current);
					depth++;

				}
			} else {
				System.out.println("Goal Node not found within depth limit");
				return false;
			}
		}

		return false;
	}

	public void Run(int limit) {

		excute();

	}
}