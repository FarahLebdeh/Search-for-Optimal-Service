package GUI;



	import java.io.IOException;
	import java.net.URL;
	import java.util.ResourceBundle;
	import javafx.event.ActionEvent;
	import javafx.fxml.FXML;
	import javafx.fxml.FXMLLoader;
	import javafx.fxml.Initializable;
	import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

	public class StartPage implements Initializable {

		@FXML
		private AnchorPane main;

		@FXML
		private Button startButton;
		
		@FXML
		private Label HEAD;
		
		
		
		@FXML
		void Start(ActionEvent event) throws IOException {
				BorderPane pane = (BorderPane) FXMLLoader.load(getClass().getResource("FXGUI.fxml"));
				main.getChildren().setAll(pane);
			}

		@FXML
		void initialize() {
			
		}

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub

		}
	}



